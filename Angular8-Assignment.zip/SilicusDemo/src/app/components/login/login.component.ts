import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription'
import { LoginDetails } from '../../models/login-details.model'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string;
  password:string;
  loggedIn:boolean;
  subscription:Subscription;
  constructor(private loginService: LoginService,private router: Router) { }

  ngOnInit(){
    let ld:LoginDetails = this.loginService.getLoginDetails();
    if(ld.isLoggedIn){
      this.router.navigate(['main']);
    }
  }
  onSubmit() {
    this.loggedIn = this.loginService.login(this.username,this.password);
    if(this.loggedIn){
      this.router.navigate(['main']);
    }
  }

}

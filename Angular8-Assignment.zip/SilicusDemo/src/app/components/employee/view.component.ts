import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginService } from '../../services/login.service'

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})

export class ViewComponent implements OnInit {
  id:number;
  constructor(private activatedRoute : ActivatedRoute, private loginService : LoginService) {
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params =>
      {
        this.id = params.id;
        if(!this.id)
        {
          this.id=99;
        }
        console.log(this.id);
      } );

  }

}

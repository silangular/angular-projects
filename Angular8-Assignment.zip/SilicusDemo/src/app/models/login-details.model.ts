export class LoginDetails {
  isLoggedIn : boolean;
  isAdmin : boolean;
  loggedInUser : string;
}

export class Employee {
  id:number;
  first_name:string;
  last_name:string;
  user_name:string;
  password:string;
  address:string;
  city:string;
  state:string;
  zip_code:string;
  dob:string;
  email:string;
  phone_no:string;
  is_admin:boolean;
}

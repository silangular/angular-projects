import { Injectable, Output  } from '@angular/core'
import { Subject } from 'rxjs/Subject'
import { Observable } from 'rxjs/Observable'
import { LoginDetails } from '../models/login-details.model'

@Injectable()
export class LoginService{

  private subject = new Subject<LoginDetails>();
  private loginDetails : LoginDetails;

  constructor(){
    this.loginDetails = new LoginDetails();
  }

  getObs = function(){
    return this.subject.asObservable();
  }

  getLoginDetails = function(){
    return this.loginDetails;
  }

  login = function(userName:string, password:string){
    if (userName==='admin' && password==="test123")
    {
      this.loginDetails.loggedInUser = userName;
      this.loginDetails.isAdmin = true;
      this.loginDetails.isLoggedIn = true;
      this.subject.next(this.loginDetails);
    }
    else if(userName==='employee' && password==="test123")
    {
      this.loginDetails.loggedInUser = userName;
      this.loginDetails.isAdmin = false;
      this.loginDetails.isLoggedIn = true;
      this.subject.next(this.loginDetails);
    }
    else { this.logout(); }

    return this.loginDetails.isLoggedIn;
  }

  logout = function(){
    this.loginDetails.loggedInUser ="";
    this.loginDetails.isAdmin=false;
    this.loginDetails.isLoggedIn=false;
  }
}

import { Injectable, OnInit } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Employee } from '../models/employee.model'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class EmployeeService implements OnInit
{
  constructor(private http:HttpClient){}
  ngOnInit(){}

  getAllEmployees(){
      return this.http.get('http://localhost:3000/employees');
  }

  getEmployee(id){
      return this.http.get<Employee>('http://localhost:3000/employees/'+id);
  }

  deleteEmployee(id){
      return this.http.delete('http://localhost:3000/employees/'+id);
  }

  updateEmployee(emp:Employee){
      let body = JSON.stringify(emp);
      return this.http.put('http://localhost:3000/employees/'+emp.id,body,httpOptions)
  }

  createEmployee(emp:Employee){
      let body = JSON.stringify(emp);
      delete emp.id;
      return this.http.post('http://localhost:3000/employees/',body,httpOptions);
  }
}
